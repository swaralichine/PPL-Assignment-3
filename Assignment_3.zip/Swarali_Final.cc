#include <iostream>
#include <istream>
#include <vector>
#include <string>
#include <cctype>
#include <stdlib.h>
#include <string.h>
#include <algorithm>

#include "lexer.h"
#include "inputbuf.h"

using namespace std;

string reserved[] = { "END_OF_FILE", "INT", "REAL", "BOOL",
                      "TRUE", "FALSE", "IF", "WHILE", "SWITCH",
                      "CASE", "PUBLIC", "PRIVATE", "NUM",
                      "REALNUM", "NOT", "PLUS", "MINUS", "MULT",
                      "DIV", "GTEQ", "GREATER", "LTEQ", "NOTEQUAL",
                      "LESS", "LPAREN", "RPAREN", "EQUAL", "COLON",
                      "COMMA", "SEMICOLON", "LBRACE", "RBRACE", "ID",
					  "ERROR" // TODO: Add labels for new token types here (as string)
};

#define KEYWORDS_COUNT 11

string keyword[] = { "int", "real", "bool", "true",
                     "false", "if", "while", "switch",
                     "case", "public", "private" };



LexicalAnalyzer input;
Token prem;
int enumCount = 4;

struct sTableEntry
{
    string name;
    int lineNo;
    int type;
    int printed;
};

struct sTable
{
    sTableEntry* item;
    sTable *prev;
    sTable *next;
};

sTable* symbolTable;
int line = 0;
string output = "";

void Token::Print()
{
    cout << "{" << this->purani << " , "
        << reserved[(int) this->gurjant] << " , "
        << this->line_no << "}\n";
}

LexicalAnalyzer::LexicalAnalyzer()
{
    this->line_no = 1;
    tmp.purani = "";
    tmp.line_no = 1;
    line = 1;
    tmp.gurjant = ERROR;
}

bool LexicalAnalyzer::SkipSpace()
{
    char c;
    bool space_encountered = false;

    input.GetChar(c);
    line_no += (c == '\n');
    line = line_no;

    while (!input.EndOfInput() && isspace(c))
    {
        space_encountered = true;
        input.GetChar(c);
        line_no += (c == '\n');
        line = line_no;
    }

    if (!input.EndOfInput())
    {
        input.UngetChar(c);
    }
    return space_encountered;
}

bool LexicalAnalyzer::SkipComments()
{
    bool comments = false;
    char c;
    if(input.EndOfInput() )
    {
        input.UngetChar(c);
        return comments;
    }

    input.GetChar(c);

    if(c == '/')
    {
        input.GetChar(c);
        if(c == '/')
        {
            comments = true;
            while(c != '\n')
            {
                comments = true;
                input.GetChar(c);
            }
            line_no++;
            line = line_no;
            SkipComments();
        }
        else
        {
            comments = false;
            cout << "Syntax Error\n";
            exit(0);
        }
    }
    else
    {
        input.UngetChar(c);
        return comments;
    }
    return true;
}

bool LexicalAnalyzer::IsKeyword(string s)
{
    for (int i = 0; i < KEYWORDS_COUNT; i++)
    {
        if (s == keyword[i])
        {
            return true;
        }
    }
    return false;
}

TokenType LexicalAnalyzer::FindKeywordIndex(string s)
{
    for (int i = 0; i < KEYWORDS_COUNT; i++)
    {
        if (s == keyword[i])
        {
            return (TokenType) (i + 1);
        }
    }
    return ERROR;
}

Token LexicalAnalyzer::ScanNumber()
{
    char c;
    bool realNUM = false;
    input.GetChar(c);
    if (isdigit(c))
    {
        if (c == '0')
        {
            tmp.purani = "0";
            input.GetChar(c);
            if(c == '.')
            {
                input.GetChar(c);

                if(!isdigit(c))
                {
                    input.UngetChar(c);
                }
                else
                {
                    while (!input.EndOfInput() && isdigit(c))
                    {
                        tmp.purani += c;
                        input.GetChar(c);
                        realNUM = true;
                    }
                    input.UngetChar(c);
                }
            }
            else
            {
                input.UngetChar(c);
            }
        }
        else
        {
            tmp.purani = "";
            while (!input.EndOfInput() && isdigit(c))
            {
                tmp.purani += c;
                input.GetChar(c);
            }
            if(c == '.')
            {
                input.GetChar(c);

                if(!isdigit(c))
                {
                    input.UngetChar(c);
                }
                else
                {
                    while (!input.EndOfInput() && isdigit(c))
                    {
                        tmp.purani += c;
                        input.GetChar(c);
                        realNUM = true;
                    }
                }
            }
            if (!input.EndOfInput())
            {
                input.UngetChar(c);
            }
        }
        // TODO: You can check for REALNUM, BASE08NUM and BASE16NUM here!
        if(realNUM)
        {
            tmp.gurjant = REALNUM;
        }
        else
        {
            tmp.gurjant = NUM;
        }
        tmp.line_no = line_no;
        return tmp;
    }
    else
    {
        if (!input.EndOfInput())
        {
            input.UngetChar(c);
        }
        tmp.purani = "";
        tmp.gurjant = ERROR;
        tmp.line_no = line_no;
        return tmp;
    }
}

Token LexicalAnalyzer::ScanIdOrKeyword()
{
    char c;
    input.GetChar(c);

    if (isalpha(c))
    {
        tmp.purani = "";
        while (!input.EndOfInput() && isalnum(c))
        {
            tmp.purani += c;
            input.GetChar(c);
        }
        if (!input.EndOfInput())
        {
            input.UngetChar(c);
        }
        tmp.line_no = line_no;

        if (IsKeyword(tmp.purani))
        {
             tmp.gurjant = FindKeywordIndex(tmp.purani);
        }
        else
        {
            tmp.gurjant = ID;
        }
    }
    else
    {
        if (!input.EndOfInput())
        {
            input.UngetChar(c);
        }
        tmp.purani = "";
        tmp.gurjant = ERROR;
    }
    return tmp;
}


TokenType LexicalAnalyzer::UngetToken(Token tok)
{
    tokens.push_back(tok);;
    return tok.gurjant;
}

Token LexicalAnalyzer::aja()
{
    char c;

    // if there are tokens that were previously
    // stored due to UngetToken(), pop a prem and
    // return it without reading from input
    if (!tokens.empty())
    {
        tmp = tokens.back();
        tokens.pop_back();
        return tmp;
    }

    SkipSpace();
    // SkipComments();
    SkipSpace();
    tmp.purani = "";
    tmp.line_no = line_no;
    input.GetChar(c);
    //cout << "\n Char obtained " << c << "\n";
    switch (c)
    {
        case '!':
            tmp.gurjant = NOT;
            return tmp;
        case '+':
            tmp.gurjant = PLUS;
            return tmp;
        case '-':
            tmp.gurjant = MINUS;
            return tmp;
        case '*':
            tmp.gurjant = MULT;
            return tmp;
        case '/':
            tmp.gurjant = DIV;
            return tmp;
        case '>':
            input.GetChar(c);
            if(c == '=')
            {
                tmp.gurjant = GTEQ;
            }
            else
            {
                input.UngetChar(c);
                tmp.gurjant = GREATER;
            }
            return tmp;
        case '<':
            input.GetChar(c);
            if(c == '=')
            {
                tmp.gurjant = LTEQ;
            }
            else if (c == '>')
            {
                tmp.gurjant = NOTEQUAL;
            }
            else
            {
                input.UngetChar(c);
                tmp.gurjant = LESS;
            }
            return tmp;
        case '(':
            //cout << "\n I am here" << c << " \n";
            tmp.gurjant = LPAREN;
            return tmp;
        case ')':
            tmp.gurjant = RPAREN;
            return tmp;
        case '=':
            tmp.gurjant = EQUAL;
            return tmp;
        case ':':
            tmp.gurjant = COLON;
            return tmp;
        case ',':
            tmp.gurjant = COMMA;
            return tmp;
        case ';':
            tmp.gurjant = SEMICOLON;
            return tmp;
        case '{':
            tmp.gurjant = LBRACE;
            return tmp;
        case '}':
            tmp.gurjant = RBRACE;
            return tmp;
        default:
            if (isdigit(c))
            {
                input.UngetChar(c);
                return ScanNumber();
            }
            else if (isalpha(c))
            {
                input.UngetChar(c);
                //cout << "\n ID scan " << c << " \n";
                return ScanIdOrKeyword();
            }
            else if (input.EndOfInput())
            {
                tmp.gurjant = END_OF_FILE;
            }
            else
            {
                tmp.gurjant = ERROR;
            }
            return tmp;
    }
}

void addList(std::string name, int line, int type)
{
    if(symbolTable != NULL)
    {
		sTable* temp = symbolTable;
        while(temp->next != NULL)
        {
          if (temp->item->name == name)
          {
            temp->item->type = type;
            return;
          }
            temp = temp->next;
        }

        sTable* newEntry = new sTable();
        sTableEntry* newItem = new sTableEntry();

        newItem->name = name;
        newItem->lineNo = prem.line_no;
        newItem->type = type;
        newItem->printed = 0;

        newEntry->item = newItem;
        newEntry->next = NULL;
        newEntry->prev = temp;
        temp->next = newEntry;
    }
    else
    {
        sTable* newEntry = new sTable();
        sTableEntry* newItem = new sTableEntry();

        newItem->name = name;
        newItem->lineNo = prem.line_no;
        newItem->type = type;
        newItem->printed = 0;

        newEntry->item = newItem;
        newEntry->next = NULL;
        newEntry->prev = NULL;

        symbolTable = newEntry;
    }
}

int searchList(std::string n)
{
    sTable* temp = symbolTable;
    bool found = false;
    if (symbolTable == NULL)
    {
        addList(n, prem.line_no, enumCount);
        enumCount++;
        return (enumCount-1);
    }
    else
    {
        while(temp->next != NULL)
        {
            if(strcmp(temp->item->name.c_str(), n.c_str()) == 0)
            {
                found = true;
                // std::cout << "while->type = "<<  temp->item->type << '\n';
                return(temp->item->type);
            }
            else
            {
                temp = temp->next;
            }
        }
        if(strcmp(temp->item->name.c_str(), n.c_str()) == 0)
        {
            found = true;
            // std::cout << "if->type = "<<  temp->item->type << '\n';
            return(temp->item->type);
        }
        if(!found)
        {
            addList(n, prem.line_no, enumCount);
            enumCount++;
            int t = enumCount-1;
            return(t);
        }
    }
    return 0;
}

int variable_list_di_parsing_jatto(){
    prem = input.aja();
    addList(prem.purani, prem.line_no, 0);
	
	
    if(prem.gurjant == ID){
        prem = input.aja();
		if(prem.gurjant == COLON) input.UngetToken(prem);
        if(prem.gurjant == COMMA) variable_list_di_parsing_jatto();
    }
	return (0);
}

int parse_body();
int parse_binaryOperator(){
    prem = input.aja();
    if(prem.gurjant != PLUS  and prem.gurjant != MINUS and prem.gurjant != MULT and prem.gurjant != DIV and prem.gurjant != GREATER and prem.gurjant !=LESS and prem.gurjant !=GTEQ and prem.gurjant !=LTEQ and prem.gurjant !=EQUAL and prem.gurjant !=NOTEQUAL ) return (-1);
}

int parse_expression(){
    int amrit;
    prem = input.aja();
	if(prem.gurjant == NOT)
    {
        input.UngetToken(prem);
        prem = input.aja();
		if(prem.gurjant != NOT) return (0);
        amrit = parse_expression();
        if(amrit != 3)
        {
            cout << "TYPE MISMATCH " << prem.line_no << " C3"<<endl;
            exit(1);
        }
    }
    else if(prem.gurjant == PLUS || prem.gurjant == MINUS || prem.gurjant == MULT || prem.gurjant == DIV || prem.gurjant == GREATER || prem.gurjant == LESS || prem.gurjant == GTEQ || prem.gurjant == LTEQ || prem.gurjant == EQUAL || prem.gurjant == NOTEQUAL)
    {
        input.UngetToken(prem);
        amrit = parse_binaryOperator();
        int lExpr = parse_expression();
        int rExpr = parse_expression();
        if((!(amrit==26) and !(amrit>=15 and amrit<=23)) or (lExpr != rExpr))
        {
			if((amrit >= 19 and amrit <= 23) or amrit == 26)
            {
                if(rExpr > 3 && lExpr > 3)
                {
					sTable* temp = symbolTable;
					while(temp->next != NULL)
					{
						if(temp->item->type == rExpr) temp->item->type = lExpr;
						temp = temp->next;
					}
					if(temp->item->type == rExpr) temp->item->type = lExpr;
                    rExpr = lExpr;
                    return(3);
                }
                else
                {
                    cout << "TYPE MISMATCH " << prem.line_no << " C2"<<endl;
                    exit(1);
                }
            }
            if(amrit >= 15 and amrit<=18)
            {
				if((lExpr <= 2 and rExpr > 3) or (lExpr > 3 and rExpr > 3))
                {
                    sTable* temp = symbolTable;
					while(temp->next != NULL)
					{
						if(temp->item->type == rExpr) temp->item->type = lExpr;
						temp = temp->next;
					}
					if(temp->item->type == rExpr) temp->item->type = lExpr;
                    rExpr = lExpr;
                }
                else if(lExpr > 3 && rExpr <= 2)
                {
                    sTable* temp = symbolTable;
					while(temp->next != NULL)
					{
						if(temp->item->type == rExpr) temp->item->type = lExpr;
						temp = temp->next;
					}
					if(temp->item->type == rExpr) temp->item->type = lExpr;
                    lExpr = rExpr;
                }
                else
                {
                    cout << "TYPE MISMATCH " << prem.line_no << " C2"<<endl;
                    exit(1);
                }
            }
            else
            {
                cout << "TYPE MISMATCH " << prem.line_no << " C2"<<endl;
                exit(1);
            }
        }
        if(amrit >= 19 and amrit <= 23 || amrit == 26) amrit = 3;
        else amrit = rExpr;
        
    }
	else if(prem.gurjant == ID || prem.gurjant == NUM || prem.gurjant == REALNUM || prem.gurjant == TRUE || prem.gurjant == FALSE )
    {
        input.UngetToken(prem);
        prem = input.aja();
		if(prem.gurjant == TRUE or prem.gurjant == FALSE) amrit=3;
		if(prem.gurjant == NUM ) amrit=1;
		if(prem.gurjant == ID ) amrit= searchList(prem.purani);
		if(prem.gurjant == REALNUM) amrit=2;		
    }
    return amrit;
}

int parse_caselist(){
    prem = input.aja();
    if(prem.gurjant == CASE){
        input.UngetToken(prem);
        prem = input.aja();
		if(prem.gurjant == CASE){
			prem = input.aja();
			if(prem.gurjant == NUM){
				prem = input.aja();
				if(prem.gurjant == COLON) parse_body();            
			}
		}
        prem = input.aja();
        if(prem.gurjant == CASE){
            input.UngetToken(prem);
            parse_caselist();
        }
        if(prem.gurjant == RBRACE) input.UngetToken(prem);
    }
    return(0);
}

int parse_stmt()
{
    prem = input.aja();
	if(prem.gurjant == SWITCH)
    {
        input.UngetToken(prem);
        int amrit;
		prem = input.aja();
		if(prem.gurjant == SWITCH)
		{
			prem = input.aja();
			if(prem.gurjant == LPAREN)
			{
				amrit = parse_expression();
				if(amrit <= 3 && amrit != 1)
				{
					cout<< "TYPE MISMATCH " << prem.line_no << " C5"<<endl;
					exit(1);
				}
				prem = input.aja();
				if(prem.gurjant == RPAREN)
				{
					prem = input.aja();
					if(prem.gurjant == LBRACE)
					{
						int amrit;
						prem = input.aja();
						if(prem.gurjant == CASE)
						{
							input.UngetToken(prem);
							prem = input.aja();
							if(prem.gurjant == CASE){
								prem = input.aja();
								if(prem.gurjant == NUM){
									prem = input.aja();
									if(prem.gurjant == COLON) parse_body();            
								}
							}
							prem = input.aja();
							if(prem.gurjant == CASE)
							{
								input.UngetToken(prem);
								amrit = parse_caselist();
							}
							if(prem.gurjant == RBRACE) input.UngetToken(prem);
						}
						return(0);	
					}
				}
			}
		}
    }
	if(prem.gurjant == WHILE)
    {
        input.UngetToken(prem);
        int amrit;
		prem = input.aja();
		if(prem.gurjant == WHILE)
		{
			prem = input.aja();
			if(prem.gurjant == LPAREN)
			{
			   
				amrit = parse_expression();
				if(amrit >= 4 and amrit <= 5) amrit = 3;
				if(amrit != 3)
				{
					cout<< "TYPE MISMATCH " << prem.line_no << " C4" << endl;
					exit(1);
				}
				prem = input.aja();
				if(prem.gurjant == RPAREN)
				{
					amrit = parse_body();
				}
			}
		}
    }
    if(prem.gurjant == IF)
    {
        input.UngetToken(prem);
        int amrit;
		prem = input.aja();
		if(prem.gurjant == IF)
		{
			prem = input.aja();
			if(prem.gurjant == LPAREN)
			{
				amrit = parse_expression();
				if(amrit != 3)
				{
					cout<< "TYPE MISMATCH " << prem.line_no << " C4" << endl;
					exit(1);
				}
				prem = input.aja();
				if(prem.gurjant == RPAREN)
				{
					amrit = parse_body();

				}
			}
		}
    }
	if(prem.gurjant == ID)
    {
        input.UngetToken(prem);
		string name;
		int LHS,RHS;
		prem = input.aja();
		if(prem.gurjant == ID)
		{
			LHS = searchList(prem.purani);
			prem = input.aja();
			if(prem.gurjant == EQUAL)
			{
				prem = input.aja();
				if(prem.gurjant == ID || prem.gurjant == NUM || prem.gurjant == REALNUM || prem.gurjant == TRUE || prem.gurjant == FALSE || prem.gurjant == PLUS || prem.gurjant == MINUS || prem.gurjant == MULT || prem.gurjant == DIV || prem.gurjant == LESS || prem.gurjant == GREATER || prem.gurjant== GTEQ || prem.gurjant== LTEQ || prem.gurjant == EQUAL || prem.gurjant == NOTEQUAL || prem.gurjant == NOT)
				{
					input.UngetToken(prem);
					RHS = parse_expression();
					if(LHS <= 3)
					{
						if(LHS != RHS)
						{
							if(LHS <= 3)
							{
								cout << "TYPE MISMATCH " << prem.line_no << " C1" << endl;
								exit(1);
							}
							else
							{
								sTable* temp = symbolTable;
								while(temp->next != NULL)
								{
									if(temp->item->type == RHS) temp->item->type = LHS;
									temp = temp->next;
								}
								if(temp->item->type == RHS) temp->item->type = LHS;
								RHS = LHS;
							}
						}
					}
					else
					{
						sTable* temp = symbolTable;
						while(temp->next != NULL)
						{
							if(temp->item->type == LHS) temp->item->type = RHS;
							temp = temp->next;
						}
						if(temp->item->type == LHS) temp->item->type = RHS;
						LHS = RHS;
					}
					prem = input.aja();
					if(prem.gurjant != SEMICOLON)
					{
						cout << "\n Syntax Error " << prem.gurjant << " \n";
					}
				}
			}
		}
	}		

}

int parse_stmtlist()
{
    prem = input.aja();
    if(prem.gurjant == ID || prem.gurjant == IF || prem.gurjant == WHILE || prem.gurjant == SWITCH)
    {
        input.UngetToken(prem);
		parse_stmt();
        prem = input.aja();
		if (prem.gurjant == RBRACE) input.UngetToken(prem);
        if(prem.gurjant == ID || prem.gurjant == IF || prem.gurjant == WHILE || prem.gurjant == SWITCH)
        {
            input.UngetToken(prem);
            parse_stmtlist();
        }
    }
}

int parse_body()
{
    prem = input.aja();
    if(prem.gurjant == LBRACE)
    {
        parse_stmtlist();
        prem = input.aja();
    }
    if(prem.gurjant == END_OF_FILE) input.UngetToken(prem);
}

int parse_program()
{
    prem = input.aja();
    while (prem.gurjant != END_OF_FILE)
    {
		if(prem.gurjant == LBRACE)
        {
            input.UngetToken(prem);
            prem = input.aja();
			if(prem.gurjant == LBRACE)
			{
				parse_stmtlist();
				prem = input.aja();
			}
			if(prem.gurjant == END_OF_FILE) input.UngetToken(prem);
        }
        if(prem.gurjant == ID)
        {
            input.UngetToken(prem);
			prem = input.aja();
			if(prem.gurjant == ID)
			{
				while(prem.gurjant == ID)
				{
					input.UngetToken(prem);
					variable_list_di_parsing_jatto();
					prem = input.aja();
					if(prem.gurjant == COLON)
					{
						prem = input.aja();
						if(prem.gurjant == INT || prem.gurjant == REAL || prem.gurjant == BOOLEAN){
							sTable* temp = symbolTable;
							while(temp->next != NULL)
							{
								if(temp->item->lineNo == prem.line_no)  temp->item->type =  prem.gurjant;
								temp = temp->next;
							}
							if(temp->item->lineNo == prem.line_no) temp->item->type =  prem.gurjant;   
						}
					}
						   
				}
			}
            parse_body();
        }
        prem = input.aja();
    }
	
	
    sTable* temp = symbolTable;
    int temp1;

    while(temp->next != NULL)
    {
		if(temp->item->type < 4 && temp->item->printed == 0)
        {
            string lCase = keyword[(temp->item->type)-1 ];
            int temp1 = temp->item->type;
            output = temp->item->name + ": " + lCase + " #";
            cout << output <<endl;
            output = "";
            temp->item->printed = 1;

            while(temp->next != NULL  && temp->next->item->type == temp1)
            {
                temp = temp->next;
                string lCase2 = keyword[(temp->item->type)-1];
                output = temp->item->name + ": " + lCase2 + " #";
                cout << output <<endl;
                temp->item->printed = 1;
                output = "";
            }
        }
		
       if(temp->item->type > 3 && temp->item->printed == 0)
        {
            temp1 = temp->item->type;
            output += temp->item->name;
            temp->item->printed = 1;
            while(temp->next != NULL)
            {
                temp = temp->next;
                if(temp->item->type == temp1)
                {
                    output += ", " + temp->item->name;
                    temp->item->printed = 1;
                }
            }
            output += ": ? #";
            cout << output <<endl;
            temp->item->printed = 1;
            output = "";
            temp = symbolTable;
        }
        
        else  temp = temp->next;
    }
	if (temp->item->type > 3 && temp->item->printed == 0)
    {
        output += temp->item->name + ":" + " ? " + "#";
        cout << output <<endl;
        output = "";
    }
    if(temp->item->type <= 3 && temp->item->printed == 0)
    {
        string lCase3 = keyword[(temp->item->type)-1];
        output += temp->item->name + ": " + lCase3 + " #";
        cout << output <<endl;
        output = "";
    }
   
    return 0;
}
int main()
{
   parse_program();
}